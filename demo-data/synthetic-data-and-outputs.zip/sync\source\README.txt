Synthetic project notes.
