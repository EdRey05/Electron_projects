Old synthetic notes.
